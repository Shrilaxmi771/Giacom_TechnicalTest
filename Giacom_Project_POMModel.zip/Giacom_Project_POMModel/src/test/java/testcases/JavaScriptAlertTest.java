package testcases;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.HomePage;
import utilities.TestUtil;

public class JavaScriptAlertTest extends BaseTest{
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	
	public void loginTest(String browserName,String username,String password) throws InterruptedException
	{
		setUp(browserName);
		HomePage home = new HomePage(driver);
		home.doLogin(username, password).gotoJSAlerts().alertvalidate();
	}
}
