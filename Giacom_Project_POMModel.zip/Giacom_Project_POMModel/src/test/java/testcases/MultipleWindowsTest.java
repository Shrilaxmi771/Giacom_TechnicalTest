package testcases;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.HomePage;
import utilities.TestUtil;

public class MultipleWindowsTest extends BaseTest {

	@Test(dataProviderClass = TestUtil.class, dataProvider = "dp")

	public void loginTest(String browserName, String username, String password) {
		setUp(browserName);
		HomePage home = new HomePage(driver);
		home.doLogin(username, password).gotoWindowPage().windowPage();
		

	}

}
