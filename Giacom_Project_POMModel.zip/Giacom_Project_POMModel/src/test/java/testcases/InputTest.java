package testcases;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.HomePage;
import utilities.TestUtil;

public class InputTest extends BaseTest {

	@Test(dataProviderClass = TestUtil.class, dataProvider = "dp")
	public void inputTest(String browserName, String username, String password,String Age,
			String Fruit, String InValidMail, String ValidMail) throws InterruptedException {

		setUp(browserName);
		HomePage home = new HomePage(driver);
		home.doLogin(username, password).gotoInputs().inputs(Age, Fruit, InValidMail, ValidMail);

	}
}
