package testcases;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.HomePage;
import utilities.TestUtil;

public class ChallengingDOMTest extends BaseTest {

	@Test(dataProviderClass = TestUtil.class, dataProvider = "dp")
	public void domTest(String browserName, String username, String password, String values) {
		
		setUp(browserName);
		HomePage home = new HomePage(driver);
		home.doLogin(username, password).gotoChangellingDOM().DOMTableCheck(values);

	}

}
