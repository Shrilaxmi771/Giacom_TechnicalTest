package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import base.BasePage;

public class InputsPage extends BasePage {

	public InputsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@id=\"content\"]/form/p[7]/button")
	public WebElement submit_btn;

	@FindBy(xpath = "//*[@id=\"r1\"]")
	public WebElement license_rdbtn;

	@FindBy(xpath = "//input[@name=\"age\"]")
	public WebElement agenum;

	@FindBy(xpath="//*[@id=\"t1\"]")
	public WebElement favfruit_txt;

	@FindBy(xpath = "//input[@type=\"email\"]")
	public WebElement mailadd;

	public void inputs(String age, String favfruit, String mailid_invalid, String mailid_valid)
			throws InterruptedException {
		
		submit_btn.click();
		WebElement inputElement = license_rdbtn;
		String validationMessage=inputElement.getAttribute("validationMessage");
		if(validationMessage.equals("Please select one of these options."))
		{
		System.out.println(validationMessage);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		boolean isRequired = (Boolean) js.executeScript("return arguments[0].required;",inputElement);
		if(isRequired )
		{
			license_rdbtn.click();
		}
		}
		
		//Enter all the manadatory field
		agenum.sendKeys(age);
		favfruit_txt.sendKeys(favfruit);

		mailadd.sendKeys(mailid_invalid);
		submit_btn.click();
		inputElement = mailadd;
		validationMessage=inputElement.getAttribute("validationMessage");
		if(validationMessage.contains("@"))
		{
		System.out.println(validationMessage);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		boolean isRequired = (Boolean) js.executeScript("return arguments[0].required;",inputElement);
		if(isRequired )
		{
			mailadd.clear();
		}
		}

		mailadd.sendKeys(mailid_valid);
		submit_btn.click();
		Thread.sleep(3000);

		submit_btn.click();
	}
}
