package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.BasePage;

public class JavaScriptAlertsPage extends BasePage {

	public JavaScriptAlertsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//*[@id=\"content\"]/div/ul/li[1]/button")
	public WebElement JSAlert_btn;

	@FindBy(xpath = "//*[@id=\"result\"]")
	public WebElement result;
	
	@FindBy(xpath="//*[@id=\"content\"]/div/ul/li[2]/button")
	public WebElement JSConfirm_btn;
	
	@FindBy(xpath="//*[@id=\"content\"]/div/ul/li[3]/button")
	public WebElement JSPrompt_btn;
	
	public void alertvalidate() throws InterruptedException {
		
		// Click on JS Alert button
		JSAlert_btn.click();
		Alert alert = driver.switchTo().alert();

		String Alerttext = alert.getText();
		if (Alerttext.equals("I am a JS Alert")) {
			System.out.println("JS Alert Message -->" + Alerttext);
			Thread.sleep(2000);
			alert.accept();
			System.out.println("Result after Alert Click -->" + result.getText());
		} else {
			System.out.println("Unable to click alert");
		}
		
		//Click on JS Confirm button
		JSConfirm_btn.click();
		 alert = driver.switchTo().alert();

		Alerttext = alert.getText();
		if (Alerttext.equals("I am a JS Confirm")) {
			System.out.println("JS Confirm Message -->" + Alerttext);
			Thread.sleep(2000);
			alert.accept();
			System.out.println("Result after Alert Click -->" + result.getText()+"\t");
		} else {
			System.out.println("Unable to click alert");
		}
		
		//Click on JS Prompt button
		JSPrompt_btn.click();
		alert = driver.switchTo().alert();

		Alerttext = alert.getText();
		if (Alerttext.equals("I am a JS prompt")) {
			System.out.println("JS Prompt Message -->" + Alerttext);
			Thread.sleep(2000);
			alert.sendKeys("Success");
			alert.accept();
			System.out.println("Result after Alert Click -->" + result.getText()+"\t");
		} else {
			System.out.println("Unable to click alert");
		}

	}

}
