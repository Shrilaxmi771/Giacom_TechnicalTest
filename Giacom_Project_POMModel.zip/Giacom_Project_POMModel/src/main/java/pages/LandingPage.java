package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.BasePage;

public class LandingPage extends BasePage {

	public LandingPage(WebDriver driver) {
		super(driver);
	}

	// Click Challenging DOM Link
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[1]/a")
	public WebElement DOM_Link;

	public ChallengingDOMPage gotoChangellingDOM() {
		DOM_Link.click();
		return new ChallengingDOMPage(driver);
	}

	// Click CheckBoxes DOM Link
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[2]/a")
	public WebElement Checkboxes_Link;

	public notPersistentCheckboxesPage gotocheckbox() {
		Checkboxes_Link.click();
		return new notPersistentCheckboxesPage(driver);
	}

	// Click on EntryAD
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[3]/a")
	public WebElement EntryAD_Link;

	public EntryAdPage gotoEntryAd() {
		EntryAD_Link.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new EntryAdPage(driver);
	}
	
	//Click on Inputs link
	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[4]/a")
	public WebElement Inputs_Link;

	public InputsPage gotoInputs() {
		Inputs_Link.click();
		return new InputsPage(driver);
	}

	//Click on JavaScript Alerts link
	@FindBy(xpath="//*[@id=\"content\"]/ul/li[5]/a")
	public WebElement JS_Alerts;
	
	public JavaScriptAlertsPage gotoJSAlerts()
	{
		JS_Alerts.click();
		return new JavaScriptAlertsPage(driver);
	}
	
	//Click on Multiple Windows link
	@FindBy(xpath="//*[@id=\"content\"]/ul/li[7]/a")
	public WebElement MultWind_Link;
	
	public MultipleWindowsPage gotoWindowPage()
	{
		MultWind_Link.click();
		return new MultipleWindowsPage(driver);
	}
	
	//logout
	public LogoutPathPage gotologout() {
		return new LogoutPathPage(driver);
	}
	
}
