package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BasePage;

public class notPersistentCheckboxesPage extends BasePage {

	public notPersistentCheckboxesPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@id=\"checkboxes\"]/input[1]")
	public WebElement checkbox1;

	@FindBy(xpath = "//*[@id=\"checkboxes\"]/input[2]")
	public WebElement checkbox2;

	@FindBy(xpath = "//*[@id=\"checkboxes\"]/text()[1]")
	public WebElement checkbox1_text;

	@FindBy(xpath = "\"//*[@id=\"checkboxes\"]/text()[2]")
	public WebElement checkbox2_text;

	@SuppressWarnings("unused")
	public void notPersistcheck() {

		// I see that checkbox 2 is checked
		boolean bval = checkbox2.isSelected();
		if (bval == true) {
			System.out.println("Second CheckBox is Selected");
			// I can un-check checkbox 2
			checkbox2.click();
			WebDriverWait wait = new WebDriverWait(driver, 10);
		} else {
			System.out.println("Second CheckBox is not Selected");
		}

		// Check 1 checkbox

		checkbox1.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		boolean bval1 = checkbox1.isSelected();
		if (bval1 == true) {
			System.out.println("First CheckBox is Selected");

		} else {
			System.out.println("First CheckBox is not Selected");
		}

	}

}
