package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.aventstack.extentreports.util.Assert;

import base.BasePage;

@SuppressWarnings("unused")
public class ChallengingDOMPage extends BasePage {

	public ChallengingDOMPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}



	public void DOMTableCheck(String value) {
		// Get all rows
		WebElement baseTable = driver.findElement(By.xpath("//*[@id=\"content\"]//table"));
		List<WebElement> rowTable = baseTable.findElements(By.tagName("tr"));
		int rs = rowTable.size();

		for (int row = 1; row < rs; row++) {
			List<WebElement> Cols_row = rowTable.get(row).findElements(By.tagName("td"));
			int columns_count = Cols_row.size();
			for (int column = 0; column < columns_count; column++) {
				String celltext = Cols_row.get(column).getText();
				if (celltext.equals(value)) {
					System.out.println("Cell Value Of row number " + row + " Is " + celltext);
					break;
				}

				
			}
		}

	}
}
