package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import base.BasePage;

public class HomePage extends BasePage {

	
	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id="username")
	public WebElement username;
	
	@FindBy(xpath="//*[@id=\"password\"]")
	public WebElement password;
	
	@FindBy(xpath="//*[@id=\"login\"]/button")
	public WebElement login;

	@FindBy(xpath="//*[@id=\"flash\"]")
	public WebElement loginPage_Msg;

	public LandingPage doLogin(String user,String pass) {
		
		username.sendKeys(user);
		password.sendKeys(pass);
		login.click();
		System.out.println("Login valid message is -->"+loginPage_Msg.getText());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		return new LandingPage(driver);
	}

}
