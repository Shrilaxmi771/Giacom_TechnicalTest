package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.BasePage;

public class LogoutPathPage extends BasePage {

	public LogoutPathPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@id=\"content\"]/a")
	public WebElement logout_link;
	
	@FindBy(xpath="//*[@id=\"flash\"]")
	public WebElement loginPage_Msg;
	
	@FindBy(xpath="//*[@id=\"login\"]/button")
	public WebElement login_btn;

	public void logoutpath() {
		logout_link.click();
		System.out.println("Logout Success Message-->"+loginPage_Msg.getText());
		
		login_btn.click();
		System.out.println("Validate login error -->"+loginPage_Msg.getText());
	}
}
