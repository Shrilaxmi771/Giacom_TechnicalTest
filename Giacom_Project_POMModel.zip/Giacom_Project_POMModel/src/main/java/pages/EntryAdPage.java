package pages;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import base.BasePage;

public class EntryAdPage extends BasePage {

	public EntryAdPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@id=\"modal\"]/div[2]/div[1]/h3")
	public WebElement modalName;

	@FindBy(xpath = "//*[@id=\"modal\"]/div[2]/div[3]/p")
	public WebElement close;

	@FindBy(id = "dropdown")
	public WebElement dropdownop;

	public void entryAd() {
		String parentWindow = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();

		for (String windowHandle : handles) {
			if (!windowHandle.equals(parentWindow)) {
				driver.switchTo().window(windowHandle);
				close.click();
				driver.switchTo().window(parentWindow);
			}
		}

		Select drpoptions = new Select(dropdownop);
		drpoptions.selectByVisibleText("Option 2");
	}

}
