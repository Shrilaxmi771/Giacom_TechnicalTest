package pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.BasePage;

public class MultipleWindowsPage extends BasePage {

	public MultipleWindowsPage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(xpath="//*[@id=\"content\"]/div/a")
	public WebElement newWindowClick;
	
	@FindBy(xpath="/html/body/div/h3")
	public WebElement newWindowText;
	
	@FindBy(xpath="//*[@id=\"content\"]/div/h3")
	public WebElement currntWindow;
	
	
	
	public void windowPage()
	{
		
		Set<String> winids=driver.getWindowHandles();
		Iterator<String> iterate=winids.iterator();
		String first_window=iterate.next();
		
		newWindowClick.click();
		
		winids=driver.getWindowHandles();
		iterate=winids.iterator();
		iterate.next();
		String second_window=iterate.next();
		driver.switchTo().window(second_window);
		String newWindowtxt=newWindowText.getText();
		if(newWindowtxt.equals("New Window"))
		{
			System.out.println("New Window is launched successfully");
		}
		else
		{
			System.out.println("New Window is not launched successfully");
		}
		driver.close();
		
		driver.switchTo().window(first_window);
		System.out.println("Value after Switching back to current Window is-->"+currntWindow.getText());
		
	}
	

}
